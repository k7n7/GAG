(function() {
    'use strict';

    const DEFAULT_CONFIG = {
        delayRight: 360,
        delayLeft: 400,
        delayBeforeKick: 250,
        autoSubmit: true
    };

    const toggleAutoSubmit = document.getElementById('kick-auto-submit');
    const inputRight = document.getElementById('kick-delay-right');
    const inputLeft = document.getElementById('kick-delay-left');
    const inputBefore = document.getElementById('kick-delay-before');
    const btnSave = document.getElementById('kick-btn-save');
    const btnReset = document.getElementById('kick-btn-reset');
    const statusEl = document.getElementById('kick-status-msg');

    function showStatus(text, color) {
        if (!statusEl) return;
        statusEl.textContent = text;
        statusEl.style.color = color;
        setTimeout(() => {
            if (statusEl.textContent === text) {
                statusEl.textContent = '';
            }
        }, 3000);
    }

    // 1. Muat konfigurasi tersimpan dari chrome.storage.local
    try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['kickConfig'], (res) => {
                const cfg = Object.assign({}, DEFAULT_CONFIG, res ? res.kickConfig : {});
                if (toggleAutoSubmit) toggleAutoSubmit.checked = cfg.autoSubmit !== false;
                if (inputRight) inputRight.value = cfg.delayRight;
                if (inputLeft) inputLeft.value = cfg.delayLeft;
                if (inputBefore) inputBefore.value = cfg.delayBeforeKick;
            });
        }
    } catch(e) {
        console.error('Gagal memuat kickConfig:', e);
    }

    // Toggle langsung simpan saat di-click
    if (toggleAutoSubmit) {
        toggleAutoSubmit.addEventListener('change', () => {
            const isAuto = toggleAutoSubmit.checked;
            try {
                if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.get(['kickConfig'], (res) => {
                        const cfg = Object.assign({}, DEFAULT_CONFIG, res ? res.kickConfig : {});
                        cfg.autoSubmit = isAuto;
                        chrome.storage.local.set({ kickConfig: cfg }, () => {
                            showStatus(`✓ Auto Submit: ${isAuto ? 'ON' : 'OFF'}!`, isAuto ? '#10b981' : '#f59e0b');
                        });
                    });
                }
            } catch(e) {}
        });
    }

    // 2. Simpan saat tombol Save diklik
    if (btnSave) {
        btnSave.addEventListener('click', () => {
            const rightVal = parseInt(inputRight ? inputRight.value : 360, 10);
            const leftVal = parseInt(inputLeft ? inputLeft.value : 400, 10);
            const beforeVal = parseInt(inputBefore ? inputBefore.value : 250, 10);
            const autoSubmitVal = toggleAutoSubmit ? toggleAutoSubmit.checked : true;

            const newCfg = {
                delayRight: (!isNaN(rightVal) && rightVal >= 0) ? rightVal : DEFAULT_CONFIG.delayRight,
                delayLeft: (!isNaN(leftVal) && leftVal >= 0) ? leftVal : DEFAULT_CONFIG.delayLeft,
                delayBeforeKick: (!isNaN(beforeVal) && beforeVal >= 0) ? beforeVal : DEFAULT_CONFIG.delayBeforeKick,
                autoSubmit: autoSubmitVal
            };

            try {
                if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.set({ kickConfig: newCfg }, () => {
                        showStatus('✓ Pengaturan delay berhasil disimpan!', '#10b981');
                        btnSave.style.opacity = '0.8';
                        setTimeout(() => { btnSave.style.opacity = '1'; }, 300);
                    });
                }
            } catch(e) {
                showStatus('Gagal menyimpan: ' + e.message, '#ef4444');
            }
        });
    }

    // 3. Reset ke default saat tombol Reset diklik
    if (btnReset) {
        btnReset.addEventListener('click', () => {
            if (toggleAutoSubmit) toggleAutoSubmit.checked = DEFAULT_CONFIG.autoSubmit;
            if (inputRight) inputRight.value = DEFAULT_CONFIG.delayRight;
            if (inputLeft) inputLeft.value = DEFAULT_CONFIG.delayLeft;
            if (inputBefore) inputBefore.value = DEFAULT_CONFIG.delayBeforeKick;

            try {
                if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.set({ kickConfig: DEFAULT_CONFIG }, () => {
                        showStatus('✓ Reset ke default (Auto Submit ON, 360ms & 400ms)!', '#38bdf8');
                    });
                }
            } catch(e) {}
        });
    }
})();
